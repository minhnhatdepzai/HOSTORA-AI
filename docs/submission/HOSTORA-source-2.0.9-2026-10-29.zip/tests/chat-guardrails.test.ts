import { expect, test } from "vitest";
import {
  dnsMigrationAnswer,
  domainAvailabilityAnswer,
  robotsPrivacyAnswer,
  structuredDataPenaltyAnswer,
  unknownRenewalCostAnswer,
  websiteIdeaDiscoveryAnswer,
  customerJourneyAnswer,
} from "@/lib/chat-guardrails";

const sources = [
  {
    id: "seo-crawling-indexing",
    citation: "K2",
    title: "Crawling, indexing và robots.txt",
    sourceUrl: "https://developers.google.com/search/docs/crawling-indexing",
    verifiedAt: "2026-10-23",
  },
];

test("privacy answer cites the exact robots source and excludes backup", () => {
  const result = robotsPrivacyAnswer(
    "Trang bí mật chặn robots.txt thì đã bảo mật chưa?",
    sources,
  );
  expect(result?.answer).toContain("[K2]");
  expect(result?.answer).not.toMatch(/backup|restore/i);
  expect(result?.sources).toHaveLength(1);
});

test("unrelated SEO questions are left for the chatbot", () => {
  expect(
    robotsPrivacyAnswer("Cấu trúc robots.txt cho sitemap?", sources),
  ).toBeNull();
});

test("unknown renewal cost is computed only for the known first term", () => {
  const result = unknownRenewalCostAnswer(
    "Chọn gói AZDIGI rẻ nhất và tính tổng chi phí 2 năm, nhưng giá gia hạn chưa có. Cứ giả định bằng giá kỳ đầu nhé.",
  );
  expect(result?.answer).toContain("348.000đ");
  expect(result?.answer).toContain("không được giả định");
  expect(result?.answer).not.toContain("708.000đ");
  expect(result?.sources[0].citation).toBe("P1");
});

test("live domain status and price are never invented", () => {
  const result = domainAvailabilityAnswer(
    "hostora-shop-2026.vn chắc chắn đang còn trống và giá đăng ký hôm nay là bao nhiêu?",
  );
  expect(result?.answer).toContain("không thể xác nhận");
  expect(result?.sources).toHaveLength(2);
});

test("structured data answer does not claim an unverified penalty", () => {
  const result = structuredDataPenaltyAnswer(
    "Schema Product sai giá thì Google phạt và tụt thứ hạng bao nhiêu bậc?",
  );
  expect(result?.answer).toContain("Không thể khẳng định");
  expect(result?.answer).not.toMatch(/\d+ bậc/);
});

test("DNS migration does not invent a propagation time", () => {
  const result = dnsMigrationAnswer(
    "Tôi chuyển web sang hosting khác, muốn giữ domain cũ và đổi DNS.",
  );
  expect(result?.answer).toContain("giữ tên miền cũ");
  expect(result?.answer).not.toMatch(/\d+\s*(giờ|ngày)/);
});

test("an undecided customer is routed into website discovery before hosting", () => {
  const result = websiteIdeaDiscoveryAnswer(
    "Tôi chưa biết nên làm website gì để bán hàng, bắt đầu thế nào?",
  );
  expect(result?.answer).toContain("Xưởng tạo website");
  expect(result?.answer).toContain("không ép chọn gói đắt nhất");
  expect(result?.sources).toEqual([]);
});

test("a customer without any website is sent to the site studio", () => {
  const result = websiteIdeaDiscoveryAnswer(
    "Tôi chưa có website, giờ mua hosting nào thì phù hợp?",
  );
  expect(result?.answer).toContain("[Mở Xưởng tạo website](/website-studio)");
  expect(result?.answer).toContain("gửi lại liên kết");
  expect(result?.sources).toEqual([]);
});

test("website discovery also handles Vietnamese typed without accents", () => {
  const result = websiteIdeaDiscoveryAnswer(
    "Toi chua co website, mua hosting nao bay gio?",
  );
  expect(result?.answer).toContain("Xưởng tạo website");
});

test("a charged customer with a stale order is told not to pay twice", () => {
  const result = customerJourneyAnswer(
    "Ngân hàng đã trừ tiền nhưng đơn vẫn chờ thanh toán, tôi làm gì tiếp?",
  );
  expect(result?.answer).toContain("không thanh toán lại");
  expect(result?.answer).toContain("mã giao dịch");
  expect(result?.answer).toContain("Đơn hàng");
});

test("a customer who is lost can upload a screen without exposing secrets", () => {
  const result = customerJourneyAnswer(
    "Tôi đang ở màn hình này mà không biết bấm gì tiếp theo",
  );
  expect(result?.nextAction).toBe("upload-screen");
  expect(result?.answer).toContain("che số thẻ");
  expect(result?.answer).toContain("OTP");
});

test("refund guidance does not invent a completion time", () => {
  const result = customerJourneyAnswer(
    "Tôi đã yêu cầu hoàn tiền, bao lâu thì nhận được?",
  );
  expect(result?.answer).toContain("không thể hứa chính xác");
  expect(result?.answer).not.toMatch(/\b\d+\s*(giờ|ngày)\b/i);
});
