const replacements: readonly (readonly [RegExp, string])[] = [
  [/\blocal AI\b/gi, "trợ lý riêng tư"],
  [/\bOllama\b/gi, "trợ lý"],
  [/\bQwen(?:[\w.:-]+)?\b/gi, "trợ lý HOSTORA"],
  [/\bRAG\b/gi, "phần tra cứu tài liệu"],
  [/\bembedding(?:s)?\b/gi, "dữ liệu tra cứu"],
  [/\btoken(?:s)?\b/gi, "phần nội dung"],
  [/\bAPI\b/gi, "kết nối"],
  [/\bbackend\b/gi, "phần xử lý"],
  [/\bfrontend\b/gi, "giao diện"],
  [/\bschema\b/gi, "mẫu thông tin"],
  [/\bfallback\b/gi, "phương án dự phòng"],
  [/\bbenchmark workload(?: thật)?\b/gi, "kiểm tra sức chịu tải thực tế"],
  [/\bbenchmark(?:ing)?\b/gi, "kiểm tra thực tế"],
  [/\bworkload\b/gi, "lượng truy cập thực tế"],
  [/\bpeak\b/gi, "lúc đông khách nhất"],
  [/\bcheckout\b/gi, "trang thanh toán"],
  [/\bdebug(?:ging)?\b/gi, "kiểm tra lỗi"],
  [/\bruntime\b/gi, "quá trình hoạt động"],
  [/\bserver response\b/gi, "thời gian phản hồi"],
  [/\bresponse time\b/gi, "thời gian phản hồi"],
  [/\bresource saturation\b/gi, "tình trạng quá tải"],
  [/\bmonitoring\b/gi, "dữ liệu theo dõi"],
  [/\bobservability\b/gi, "việc theo dõi hoạt động"],
  [/\berror rate\b/gi, "tỷ lệ lỗi"],
  [/\bthroughput\b/gi, "số yêu cầu có thể xử lý"],
  [/\bload test(?:ing)?\b/gi, "thử khi nhiều khách cùng truy cập"],
  [/\bconcurrent users?\b/gi, "người truy cập cùng lúc"],
  [/\bconcurrency\b/gi, "số người truy cập cùng lúc"],
  [/\bsố người đồng thời\b/gi, "số người truy cập cùng lúc"],
  [/\btraffic\b/gi, "lượng khách truy cập"],
  [/\bendpoint\b/gi, "địa chỉ kết nối"],
  [/\binference\b/gi, "việc trả lời"],
  [/\bstreaming\b/gi, "phản hồi liên tục"],
  [/\bpipeline\b/gi, "quy trình"],
  [/\bdeploy(?:ment)?\b/gi, "đưa vào sử dụng"],
  [/\bproduction\b/gi, "môi trường sử dụng thật"],
  [/\bserver\b/gi, "hệ thống"],
  [/\bplugin(?:s)?\b/gi, "tiện ích mở rộng"],
  [/\bcache\b/gi, "cách lưu nội dung tạm thời"],
  [/\bdatabase\b/gi, "kho dữ liệu"],
  [/\bquery\b/gi, "thao tác tìm dữ liệu"],
  [/\bCDN\b/g, "dịch vụ tăng tốc"],
  [/\bSSL\b/g, "kết nối an toàn"],
  [/\bHTML\b/g, "nội dung trang"],
  [/\bCPU\b/g, "khả năng xử lý"],
  [/\bRAM\b/g, "bộ nhớ hoạt động"],
  [/\bGPU\b/g, "bộ xử lý hình ảnh"],
  [/\b(?:lỗi\s+)?5xx\b/gi, "lỗi khiến khách không mở được trang"],
  [/\bI\/O\b/g, "tốc độ đọc và lưu dữ liệu"],
  [/\blatency\b/gi, "thời gian chờ"],
  [/\bmã nguồn\b/gi, "nền tảng website"],
  [/\bcode\b/gi, "cách website được xây dựng"],
  [/\btrade[- ]?off\b/gi, "điểm cần cân nhắc"],
  [/\bchịu tải\b/gi, "phục vụ nhiều khách cùng lúc"],
  [/\btài nguyên\b/gi, "khả năng của gói"],
  [/kho dữ liệu thời gian chờ/gi, "thời gian chờ khi đọc dữ liệu"],
  [/\bfine[- ]?tuning\b/gi, "cải thiện cách tư vấn"],
  [/\btraining\b/gi, "quá trình học từ tình huống đã duyệt"],
  [/\bsandbox\b/gi, "môi trường thử nghiệm"],
  [/\bSMTP\b/g, "dịch vụ gửi thư"],
  [/\bwebhook\b/gi, "thông báo giao dịch tự động"],
  [/\bgateway\b/gi, "nơi thanh toán"],
  [/\bprovider(?:s)?\b/gi, "nhà cung cấp"],
  [/\bOCR\b/g, "đọc nội dung trong ảnh"],
  [/\bSEO\b/g, "khả năng được tìm thấy trên Google"],
  [/\bcatalog\b/gi, "danh sách dịch vụ"],
  [/\bwebsite\b/gi, "trang web"],
  [/\bhosting\b/gi, "lưu trữ trang web"],
  [/\bemail\b/gi, "thư điện tử"],
  [/\bchat\b/gi, "trò chuyện"],
  [/\bapp\b/gi, "ứng dụng"],
  [/\bshop\b/gi, "cửa hàng"],
  [/\blanding page\b/gi, "trang giới thiệu"],
  [/\bmanaged\b/gi, "được quản lý"],
  [/\bcloud\b/gi, "đám mây"],
];

/** Keeps internal implementation vocabulary out of customer-facing AI prose. */
export function toCustomerLanguage(value: string) {
  // Preserve source links and literal code while translating customer prose.
  const output = value
    .split(/(\((?:https?:\/\/|\/)[^\s<>\)]+\)|https?:\/\/[^\s<>\)]+|`[^`]*`)/g)
    .map((part) => {
      if (
        /^(?:https?:\/\/|\((?:https?:\/\/|\/))/.test(part) ||
        part.startsWith("`")
      )
        return part;
      return replacements.reduce(
        (text, [pattern, replacement]) => text.replace(pattern, replacement),
        part,
      );
    })
    .join("");
  return value[0] === value[0]?.toLocaleUpperCase("vi-VN") && output[0]
    ? output[0].toLocaleUpperCase("vi-VN") + output.slice(1)
    : output;
}
