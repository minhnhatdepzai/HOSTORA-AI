import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";

export default defineConfig([
  ...nextVitals,
  ...nextTs,
  globalIgnores([
    ".next/**",
    "coverage/**",
    "output/**",
    "playwright-report/**",
    "public/vendor/**",
    "test-results/**",
    "data/rag-index.json",
    "mobile/**",
    "training/.venv/**",
    "training/output-smoke/**",
  ]),
]);
